# duckieteam-fall2017
The Duckieteam folder for Fall 2017 (ETHZ, UdeM, TTIC, NCTU)

Contains robot names and calibrations.

